# Futebol Campo Online – Ouro & Prata | Vercel

Projeto frontend Vite preparado para publicação na Vercel e conectado ao Supabase.

## Variáveis de ambiente na Vercel

Configure em **Project Settings → Environment Variables**:

- `VITE_SUPABASE_URL` = `https://kfsxzpyzohcvzlsfvtyx.supabase.co`
- `VITE_SUPABASE_PUBLISHABLE_KEY` = a Publishable Key do projeto Supabase

Não publique service-role keys ou outras chaves secretas no frontend.

## Build

- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Install command: `npm install`

O `vercel.json` já inclui o rewrite para o `index.html`, necessário para a navegação da aplicação SPA.
