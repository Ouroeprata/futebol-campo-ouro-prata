-- Cronômetro persistente da súmula
alter table public.matches add column if not exists first_half_elapsed_seconds integer not null default 0;
alter table public.matches add column if not exists second_half_elapsed_seconds integer not null default 0;
