
create extension if not exists pgcrypto;

create type public.user_role as enum ('admin','organizador','arbitro','operador','publico');
create type public.match_status as enum ('agendado','em_andamento','intervalo','finalizado','cancelado');
create type public.event_type as enum ('gol','cartao_amarelo','cartao_vermelho','substituicao','ocorrencia');
create type public.lineup_status as enum ('titular','reserva');

create table public.competitions (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 edition text,
 max_groups int not null default 8 check (max_groups between 1 and 8),
 points_win int not null default 3,
 points_draw int not null default 1,
 created_at timestamptz not null default now()
);

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null,
 role public.user_role not null default 'publico',
 created_at timestamptz not null default now()
);

create table public.groups (
 id uuid primary key default gen_random_uuid(),
 competition_id uuid not null references public.competitions(id) on delete cascade,
 code char(1) not null check(code between 'A' and 'H'),
 unique(competition_id,code)
);

create table public.teams (
 id uuid primary key default gen_random_uuid(),
 competition_id uuid not null references public.competitions(id) on delete cascade,
 name text not null,
 short_name text,
 logo_url text,
 group_id uuid references public.groups(id) on delete set null,
 created_at timestamptz not null default now()
);

create table public.players (
 id uuid primary key default gen_random_uuid(),
 team_id uuid not null references public.teams(id) on delete cascade,
 name text not null,
 shirt_number int,
 position text,
 photo_url text,
 active boolean not null default true
);

create table public.referees (
 id uuid primary key default gen_random_uuid(),
 competition_id uuid not null references public.competitions(id) on delete cascade,
 name text not null,
 registration text,
 category text,
 photo_url text,
 active boolean not null default true
);

create table public.matches (
 id uuid primary key default gen_random_uuid(),
 competition_id uuid not null references public.competitions(id) on delete cascade,
 home_team_id uuid not null references public.teams(id),
 away_team_id uuid not null references public.teams(id),
 referee_id uuid references public.referees(id),
 assistant_referee_1 uuid references public.referees(id),
 assistant_referee_2 uuid references public.referees(id),
 fourth_referee uuid references public.referees(id),
 field_name text,
 scheduled_at timestamptz not null,
 status public.match_status not null default 'agendado',
 home_score int not null default 0,
 away_score int not null default 0,
 first_half_minutes int not null default 45,
 second_half_minutes int not null default 45,
 added_time_1 int not null default 0,
 added_time_2 int not null default 0,
 created_at timestamptz not null default now(),
 check(home_team_id <> away_team_id)
);

create table public.match_lineups (
 match_id uuid not null references public.matches(id) on delete cascade,
 player_id uuid not null references public.players(id) on delete cascade,
 team_id uuid not null references public.teams(id),
 status public.lineup_status not null,
 captain boolean not null default false,
 primary key(match_id,player_id)
);

create table public.match_events (
 id uuid primary key default gen_random_uuid(),
 match_id uuid not null references public.matches(id) on delete cascade,
 team_id uuid references public.teams(id),
 player_id uuid references public.players(id),
 type public.event_type not null,
 minute int,
 related_player_id uuid references public.players(id),
 description text,
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);

create table public.match_votes (
 match_id uuid not null references public.matches(id) on delete cascade,
 player_id uuid not null references public.players(id) on delete cascade,
 voter_id uuid references auth.users(id),
 created_at timestamptz not null default now(),
 primary key(match_id,player_id,voter_id)
);

create table public.audit_log (
 id uuid primary key default gen_random_uuid(),
 actor_id uuid references auth.users(id),
 action text not null,
 table_name text,
 record_id uuid,
 payload jsonb,
 created_at timestamptz not null default now()
);

-- Helper functions
create or replace function public.is_staff()
returns boolean language sql stable security definer as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('admin','organizador','arbitro','operador'));
$$;

create or replace function public.is_admin_or_org()
returns boolean language sql stable security definer as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('admin','organizador'));
$$;

-- RLS
alter table public.competitions enable row level security;
alter table public.groups enable row level security;
alter table public.teams enable row level security;
alter table public.players enable row level security;
alter table public.referees enable row level security;
alter table public.matches enable row level security;
alter table public.match_lineups enable row level security;
alter table public.match_events enable row level security;
alter table public.match_votes enable row level security;
alter table public.profiles enable row level security;
alter table public.audit_log enable row level security;

create policy "public read competitions" on public.competitions for select using (true);
create policy "public read groups" on public.groups for select using (true);
create policy "public read teams" on public.teams for select using (true);
create policy "public read players" on public.players for select using (true);
create policy "public read referees" on public.referees for select using (true);
create policy "public read matches" on public.matches for select using (true);
create policy "public read lineups" on public.match_lineups for select using (true);
create policy "public read events" on public.match_events for select using (true);

create policy "staff manage competitions" on public.competitions for all using (public.is_admin_or_org()) with check (public.is_admin_or_org());
create policy "staff manage groups" on public.groups for all using (public.is_admin_or_org()) with check (public.is_admin_or_org());
create policy "staff manage teams" on public.teams for all using (public.is_admin_or_org()) with check (public.is_admin_or_org());
create policy "staff manage players" on public.players for all using (public.is_admin_or_org()) with check (public.is_admin_or_org());
create policy "staff manage referees" on public.referees for all using (public.is_admin_or_org()) with check (public.is_admin_or_org());
create policy "staff manage matches" on public.matches for all using (public.is_staff()) with check (public.is_staff());
create policy "staff manage lineups" on public.match_lineups for all using (public.is_staff()) with check (public.is_staff());
create policy "staff manage events" on public.match_events for all using (public.is_staff()) with check (public.is_staff());

create policy "authenticated vote" on public.match_votes for insert to authenticated with check (voter_id=auth.uid());
create policy "own votes" on public.match_votes for select to authenticated using (voter_id=auth.uid());

create policy "own profile" on public.profiles for select using (id=auth.uid());
create policy "admin profiles" on public.profiles for all using (
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);

-- Useful standings view
create or replace view public.match_results as
select
 m.id, m.competition_id, m.home_team_id, m.away_team_id,
 m.home_score, m.away_score, m.status
from public.matches m
where m.status='finalizado';

-- Realtime
alter publication supabase_realtime add table public.matches;
alter publication supabase_realtime add table public.match_events;
alter publication supabase_realtime add table public.match_lineups;
alter publication supabase_realtime add table public.match_votes;
